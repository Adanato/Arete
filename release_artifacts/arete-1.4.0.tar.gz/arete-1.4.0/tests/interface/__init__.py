# Tests for interface layer (CLI)
