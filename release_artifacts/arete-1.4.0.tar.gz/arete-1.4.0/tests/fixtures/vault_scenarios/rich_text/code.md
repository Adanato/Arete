---
deck: IntegrationTest::RichContent
arete: true
cards:
  - nid: null
    Front: |
      Code:
      ```python
      print("hello")
      ```
    Back: Code Verified
---
# Code Card
