---
deck: IntegrationTest
arete: true
cards:
  - nid: null
    model: O2A_Basic
    Front: Prune Candidate
    Back: Gone

---
