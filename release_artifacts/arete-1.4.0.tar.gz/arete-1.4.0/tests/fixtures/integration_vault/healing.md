---
deck: IntegrationTest
arete: true
cards:
  - nid: null
    Front: Healing Candidate
    Back: Same Back
---
# Card
