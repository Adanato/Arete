---
arete: true
deck: test
model: Basic
tags:
- algebra
- field
cards:
- Front: Define a field.dafas
  Back: |-
    A set $F$ with two operations $+$ and $\times$ satisfying the field axioms.
  nid: '1768444496512'
- Front: Give an example of a fadfasdfield.
  Back: |-
    $\mathbb{Q}$ is a field under standard addition and multiplication.
  nid: '1768444496517'
---
