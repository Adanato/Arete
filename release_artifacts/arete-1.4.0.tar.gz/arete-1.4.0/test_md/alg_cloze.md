---
arete: true
deck: test
model: Cloze
tags: [algebra, field, cloze]
cards:
    - Text: "A field is a set with {{c1::two operations}} satisfying {{c2::five field axioms}}."
    Extra: "These operations are usually addition and multiplication."
    - Text: "In a field, the additive identity is {{c1::0}}."
---
# Cloze Notes

Some additional notes about cloze cards.
