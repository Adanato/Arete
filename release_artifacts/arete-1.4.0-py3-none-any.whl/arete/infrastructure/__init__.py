# Infrastructure layer - External adapters and utilities
