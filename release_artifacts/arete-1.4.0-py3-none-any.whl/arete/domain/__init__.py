# Domain layer - Core business models and interfaces
