# Anki-Connect

This repository has permanently moved to https://git.sr.ht/~foosoft/anki-connect.
