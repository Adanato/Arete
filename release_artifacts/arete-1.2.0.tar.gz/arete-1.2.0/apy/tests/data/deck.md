# Basic note
tags: marked
model: Basic
deck: Default

## Front
Question 1 | deck.md

## Back
Answer 1

# Basic note
tags: cool, works
model: Basic
deck: NewDeck

## Front
Question 2 | deck.md

## Back
Answer 2

