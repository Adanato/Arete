tags: marked
model: Basic (type in the answer)

# Basic note
model: Basic

## Front
Question 1

## Back
Answer 1

# Basic note
tags: cool, works

## Front
Question 2

## Back
Answer 2

