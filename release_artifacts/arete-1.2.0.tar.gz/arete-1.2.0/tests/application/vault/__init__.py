# Tests for vault service
