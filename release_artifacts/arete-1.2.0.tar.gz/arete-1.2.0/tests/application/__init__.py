# Tests for application layer (pipeline, config, wizard, vault, parser)
