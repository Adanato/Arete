"""
Obsidian Source Link - Anki Add-on
Opens the source Obsidian file when reviewing cards or browsing.

Features:
1. Right-click context menu in Browse to open in Obsidian
2. Button/shortcut during Review (Ctrl+Shift+O)

Requires: Obsidian Advanced URI plugin for line-level navigation.

Config:
Create a file called 'config.json' in the add-on folder with:
{
    "vault_name_override": "My Vault Name"
}
This will replace the vault name stored in cards when opening Obsidian.
"""

import json
import os
import webbrowser
from urllib.parse import quote

from aqt import gui_hooks, mw
from aqt.browser import Browser
from aqt.qt import QAction, QKeySequence, QMenu
from aqt.reviewer import Reviewer
from aqt.utils import showWarning, tooltip

# ─────────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────────

ADDON_PATH = os.path.dirname(__file__)
CONFIG_PATH = os.path.join(ADDON_PATH, "config.json")
CONFIG = {}

def load_config():
    global CONFIG
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                CONFIG = json.load(f)
        except Exception:
            CONFIG = {}

load_config()

# ─────────────────────────────────────────────────────────────────────────────
# Core Logic
# ─────────────────────────────────────────────────────────────────────────────


def get_obsidian_source(note) -> tuple[str, str, int] | None:
    """
    Extract Obsidian source info from note's _obsidian_source field.
    Returns (vault_name, file_path, card_index) or None if not found.
    """
    for field_name in note.keys():
        if field_name == "_obsidian_source":
            field_value = note[field_name]
            if field_value:
                # Strip HTML tags if any (legacy sync issues)
                import re
                clean_value = re.sub(r'<[^>]*>', '', field_value).strip()

                # Format: vault|path|index
                parts = clean_value.split("|")
                if len(parts) >= 3:
                    vault = parts[0]
                    file_path = parts[1]
                    try:
                        card_idx = int(parts[2])
                    except ValueError:
                        card_idx = 1
                    return vault, file_path, card_idx
    return None


def open_obsidian_uri(vault: str, file_path: str, card_idx: int = 1) -> bool:
    """
    Open Obsidian via URI scheme.
    Returns True on success, False on failure.
    """
    # Allow config to override vault name
    actual_vault = CONFIG.get("vault_name_override", vault) or vault
    
    encoded_vault = quote(actual_vault)
    encoded_path = quote(file_path)

    # Use Advanced URI for line-level navigation (requires Advanced URI plugin in Obsidian)
    uri = f"obsidian://advanced-uri?vault={encoded_vault}&filepath={encoded_path}&line={card_idx}"

    # Fallback: Standard URI (no line navigation, but works without plugins)
    # uri = f"obsidian://open?vault={encoded_vault}&file={encoded_path}"

    try:
        webbrowser.open(uri)
        return True
    except Exception as e:
        showWarning(f"Failed to open Obsidian: {e}")
        return False


# ─────────────────────────────────────────────────────────────────────────────
# Feature 1: Reviewer Button/Shortcut
# ─────────────────────────────────────────────────────────────────────────────


def open_current_card_in_obsidian():
    """Open current reviewing card's source in Obsidian."""
    reviewer = mw.reviewer
    if not reviewer or not reviewer.card:
        showWarning("No card is currently being reviewed.")
        return

    note = reviewer.card.note()
    source = get_obsidian_source(note)

    if not source:
        showWarning(
            "No Obsidian source found for this card.\n\n"
            "Make sure the card was synced with arete and has the "
            "'_obsidian_source' field."
        )
        return

    vault, file_path, card_idx = source
    if open_obsidian_uri(vault, file_path, card_idx):
        tooltip(f"Opening in Obsidian: {file_path}")


def setup_reviewer_shortcut():
    """Add keyboard shortcut and menu item."""
    action = QAction("Open in Obsidian", mw)
    action.setShortcut(QKeySequence("Ctrl+Shift+O"))
    action.triggered.connect(open_current_card_in_obsidian)
    mw.form.menuTools.addAction(action)


# ─────────────────────────────────────────────────────────────────────────────
# Feature 2: Browse Right-Click Context Menu
# ─────────────────────────────────────────────────────────────────────────────


def on_browser_context_menu(browser: Browser, menu: QMenu):
    """Add 'Open in Obsidian' to browser right-click menu."""
    selected = browser.selectedNotes()
    if not selected:
        return

    action = menu.addAction("Open in Obsidian")
    action.triggered.connect(lambda: open_selected_notes_in_obsidian(browser))


def open_selected_notes_in_obsidian(browser: Browser):
    """Open selected notes in Obsidian (first one if multiple selected)."""
    selected = browser.selectedNotes()
    if not selected:
        showWarning("No notes selected.")
        return

    # Open first selected note
    note_id = selected[0]
    note = mw.col.get_note(note_id)

    source = get_obsidian_source(note)
    if not source:
        showWarning(
            "No Obsidian source found for this note.\n\n"
            "Make sure the note was synced with arete and has the "
            "'_obsidian_source' field."
        )
        return

    vault, file_path, card_idx = source
    if open_obsidian_uri(vault, file_path, card_idx):
        tooltip(f"Opening in Obsidian: {file_path}")

    # If multiple selected, notify user
    if len(selected) > 1:
        tooltip(f"Opened first of {len(selected)} selected notes")


# ─────────────────────────────────────────────────────────────────────────────
# AnkiConnect Custom Actions
# ─────────────────────────────────────────────────────────────────────────────


def on_anki_connect_call(method: str, params: dict, context: dict):
    """
    Handle custom AnkiConnect actions.
    Example call: {"action": "showTooltip", "params": {"msg": "Sync complete!"}}
    """
    if method == "showTooltip":
        msg = params.get("msg", "No message provided")
        period = params.get("period", 3000)
        tooltip(msg, period=period)
        return True

    if method == "getFSRSStats":
        card_ids = params.get("cards", [])
        results = []
        for cid in card_ids:
            try:
                card = mw.col.get_card(cid)
                difficulty = None
                
                # 1. Native FSRS (Anki 23.10+)
                # card.memory_state might be available
                if hasattr(card, "memory_state") and card.memory_state:
                    # memory_state.difficulty is usually 0-10 or 1-10
                    # Standard FSRS is 1-10.
                    difficulty = card.memory_state.difficulty

                # 2. Custom Data (JSON in .data field) - Legacy FSRS / Helper
                if difficulty is None and card.data:
                    import json
                    try:
                        data = json.loads(card.data)
                        if 'd' in data: 
                             difficulty = data['d']
                        elif 'fsrs' in data and 'd' in data['fsrs']:
                             difficulty = data['fsrs']['d']
                        # Some versions use 'D' or other keys, but 'd' is standard.
                    except:
                        pass
                
                results.append({"cardId": cid, "difficulty": difficulty})
            except Exception as e:
                 # Card not found or other error
                 results.append({"cardId": cid, "difficulty": None, "error": str(e)})
        
        return results

    return None


# ─────────────────────────────────────────────────────────────────────────────
# Initialization
# ─────────────────────────────────────────────────────────────────────────────


# Add reviewer shortcut
setup_reviewer_shortcut()

# Add browser context menu hook
gui_hooks.browser_will_show_context_menu.append(on_browser_context_menu)

# Try to hook into AnkiConnect if it's installed
# AnkiConnect hook is now handled by direct patching of the AnkiConnect add-on.
# This file only registers the custom actions if needed in future, but for now
# we rely on the patched AnkiConnect to provide 'getFSRSStats'.
