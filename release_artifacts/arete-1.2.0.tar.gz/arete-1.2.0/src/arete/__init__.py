def hello() -> str:
    return "Hello from obsidian-2-anki!"


__version__ = "1.2.0"
